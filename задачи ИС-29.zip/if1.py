i=float(input())
if i>0:
    i+=1
print(i)